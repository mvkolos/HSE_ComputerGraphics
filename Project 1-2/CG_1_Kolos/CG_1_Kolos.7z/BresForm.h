#pragma once

/*����� ����� ������������, ���141, 
04.10.17, 
������ 2. �����,
� Visual Studio 2017 Community, Windows 10
���������� �������
���������� ���������
.*/
#using <System.dll>
#using <System.Windows.Forms.dll>
#using <System.Drawing.dll>

namespace CG_1_Kolos {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	
	typedef int outcode;
	//enum { INSIDE=0x0,TOP = 0x8, BOTTOM = 0x4, RIGHT = 0x2, LEFT = 0x1 };
	//typedef int OutCode;

	const int INSIDE = 0; // 0000
	const int LEFT = 1;   // 0001
	const int RIGHT = 4;  // 0100
	const int BOTTOM = 8; // 1000
	const int TOP = 2;    // 0010

	/// <summary>
	/// ������ ��� BresForm
	/// </summary>
	public ref class BresForm : public System::Windows::Forms::Form
	{
		

	public:
		BresForm(void)
		{
			InitializeComponent();

			pointCount = 0;
			bm = gcnew Bitmap(pictureBox->Width, pictureBox->Height);
			pictureBox->Image = bm;
			refresh();

			lastPoint = Point(pictureBox->Width / 2, pictureBox->Height / 2);//�������� ��� ��� ����������
			bresenham = false;//���������� Graphics
			checkBoxBres->Checked = true;
			thickness = 1;
			radius = 20;
			height = 20;
			width = 10;
			DoubleBuffered = true;
			int a = 8;
			int b = 2;
			textBoxDebug->Text = (bool(a & b)).ToString();// +" " + (boolean(a | b)).ToString();
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~BresForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;
		Bitmap^ bm;
	private: System::Windows::Forms::CheckBox^  checkBoxBres;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::PictureBox^  pictureBox;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Button^  buttonCircle;
	private: System::Windows::Forms::Button^  buttonEllipse;
	private: System::Windows::Forms::Button^  buttonLine;
	private: System::Windows::Forms::TrackBar^  trackBarThick;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  buttonFill;
	private: System::Windows::Forms::TextBox^  textBoxDebug;
	private: System::Windows::Forms::Button^  buttonRect;


			 int pointCount;

			 void drawLine(Graphics^g,
							Point start, 
							Point end,
							bool save,
							bool xor, 
							System::Collections::Generic::List<Point> border);
			 
			 void drawEllipse(Graphics^ g, 
							Point center, 
							int width, 
							int height);
			 void drawFourPoints(Pen^ pen, 
							Point center, 
							int x, 
							int y);
			 void drawBuiltIn();
			 void refresh();
			 void redraw();
			 void SeedFill(Graphics ^g,
							Point seed, 
							Color new_color);
			 void _Fill(Graphics ^g,
							Color old_color, 
							Color new_color);
			 void paint(Graphics ^g,bool save);
			 void _CheckLine(int left, 
							int right,
							int y, 
							Color old_color, 
							Color new_color);
			 bool compareColors(Color r, Color l);
			 
			 void push(int x, int y);

			 void XORFill();
			 
			 
			 void CohenSutherlandClipping(
							System::Drawing::Rectangle rect, 
							Graphics ^g,
							int mode);
			 outcode computeOutcode(int x, int y, 
							System::Drawing::Rectangle rect);
			 Pen^ getColor(int code1,int code2);

			 Point currentPoint;
			 Point lastPoint;
			 bool bresenham;//whether bresenham algorithm is used, otherwise built-in functions
			 int tool = 0;
			 int radius;

			 int thickness;//line thickness
			 bool fill = false;
			 int height;//ellipse height/width
			 int width;
			 System::Drawing::Rectangle mRect;
			 SolidBrush ^_ghostBrush;
			 bool draw;
			 System::Collections::Generic::Stack<Point> pixels;
			 int recCount = 0;
			 Color border;
			 bool contains(Point p);
			 Point line_start = Point(-1, -1);
			 System::Collections::Generic::List< System::Tuple<Point, Point>^> lines;
			 //System::Tuple<Point, Point> p;
			 
			 //System::Drawing::

#pragma region Windows Form Designer generated code
			 /// <summary>
			 /// ��������� ����� ��� ��������� ������������ � �� ��������� 
			 /// ���������� ����� ������ � ������� ��������� ����.
			 /// </summary>
			 void InitializeComponent(void)
			 {
				 System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(BresForm::typeid));
				 this->checkBoxBres = (gcnew System::Windows::Forms::CheckBox());
				 this->button1 = (gcnew System::Windows::Forms::Button());
				 this->pictureBox = (gcnew System::Windows::Forms::PictureBox());
				 this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
				 this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				 this->panel1 = (gcnew System::Windows::Forms::Panel());
				 this->buttonFill = (gcnew System::Windows::Forms::Button());
				 this->buttonLine = (gcnew System::Windows::Forms::Button());
				 this->buttonEllipse = (gcnew System::Windows::Forms::Button());
				 this->buttonCircle = (gcnew System::Windows::Forms::Button());
				 this->trackBarThick = (gcnew System::Windows::Forms::TrackBar());
				 this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
				 this->textBoxDebug = (gcnew System::Windows::Forms::TextBox());
				 this->buttonRect = (gcnew System::Windows::Forms::Button());
				 (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox))->BeginInit();
				 this->menuStrip1->SuspendLayout();
				 this->panel1->SuspendLayout();
				 (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBarThick))->BeginInit();
				 (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
				 this->SuspendLayout();
				 // 
				 // checkBoxBres
				 // 
				 this->checkBoxBres->AutoSize = true;
				 this->checkBoxBres->Location = System::Drawing::Point(98, 39);
				 this->checkBoxBres->Name = L"checkBoxBres";
				 this->checkBoxBres->Size = System::Drawing::Size(79, 17);
				 this->checkBoxBres->TabIndex = 3;
				 this->checkBoxBres->Text = L"Bresenham";
				 this->checkBoxBres->UseVisualStyleBackColor = true;
				 this->checkBoxBres->CheckedChanged += gcnew System::EventHandler(this, &BresForm::checkBox1_CheckedChanged);
				 // 
				 // button1
				 // 
				 this->button1->BackColor = System::Drawing::SystemColors::AppWorkspace;
				 this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
				 this->button1->Location = System::Drawing::Point(6, 274);
				 this->button1->Name = L"button1";
				 this->button1->Size = System::Drawing::Size(50, 31);
				 this->button1->TabIndex = 4;
				 this->button1->Text = L"clear";
				 this->button1->UseVisualStyleBackColor = false;
				 this->button1->Click += gcnew System::EventHandler(this, &BresForm::button1_Click);
				 // 
				 // pictureBox
				 // 
				 this->pictureBox->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
					 | System::Windows::Forms::AnchorStyles::Left)
					 | System::Windows::Forms::AnchorStyles::Right));
				 this->pictureBox->Location = System::Drawing::Point(98, 85);
				 this->pictureBox->MaximumSize = System::Drawing::Size(600, 600);
				 this->pictureBox->MinimumSize = System::Drawing::Size(200, 200);
				 this->pictureBox->Name = L"pictureBox";
				 this->pictureBox->Size = System::Drawing::Size(400, 400);
				 this->pictureBox->TabIndex = 5;
				 this->pictureBox->TabStop = false;
				 this->pictureBox->Click += gcnew System::EventHandler(this, &BresForm::pictureBox_Click);
				 this->pictureBox->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &BresForm::pictureBox_Paint);
				 this->pictureBox->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &BresForm::pictureBox_MouseDown);
				 this->pictureBox->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &BresForm::pictureBox_MouseMove);
				 this->pictureBox->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &BresForm::pictureBox_MouseUp);
				 this->pictureBox->Resize += gcnew System::EventHandler(this, &BresForm::BresForm_Load);
				 // 
				 // menuStrip1
				 // 
				 this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->aboutToolStripMenuItem });
				 this->menuStrip1->Location = System::Drawing::Point(0, 0);
				 this->menuStrip1->Name = L"menuStrip1";
				 this->menuStrip1->Size = System::Drawing::Size(525, 24);
				 this->menuStrip1->TabIndex = 22;
				 this->menuStrip1->Text = L"menuStrip1";
				 // 
				 // aboutToolStripMenuItem
				 // 
				 this->aboutToolStripMenuItem->Alignment = System::Windows::Forms::ToolStripItemAlignment::Right;
				 this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
				 this->aboutToolStripMenuItem->Size = System::Drawing::Size(50, 20);
				 this->aboutToolStripMenuItem->Text = L"about";
				 this->aboutToolStripMenuItem->Click += gcnew System::EventHandler(this, &BresForm::aboutToolStripMenuItem_Click);
				 // 
				 // panel1
				 // 
				 this->panel1->Controls->Add(this->buttonRect);
				 this->panel1->Controls->Add(this->buttonFill);
				 this->panel1->Controls->Add(this->button1);
				 this->panel1->Controls->Add(this->buttonLine);
				 this->panel1->Controls->Add(this->buttonEllipse);
				 this->panel1->Controls->Add(this->buttonCircle);
				 this->panel1->Location = System::Drawing::Point(12, 27);
				 this->panel1->Name = L"panel1";
				 this->panel1->Size = System::Drawing::Size(63, 465);
				 this->panel1->TabIndex = 23;
				 // 
				 // buttonFill
				 // 
				 this->buttonFill->Location = System::Drawing::Point(6, 311);
				 this->buttonFill->Name = L"buttonFill";
				 this->buttonFill->Size = System::Drawing::Size(50, 23);
				 this->buttonFill->TabIndex = 5;
				 this->buttonFill->Text = L"fill";
				 this->buttonFill->UseVisualStyleBackColor = true;
				 this->buttonFill->Click += gcnew System::EventHandler(this, &BresForm::buttonFill_Click);
				 // 
				 // buttonLine
				 // 
				 this->buttonLine->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonLine.BackgroundImage")));
				 this->buttonLine->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
				 this->buttonLine->Location = System::Drawing::Point(6, 148);
				 this->buttonLine->Name = L"buttonLine";
				 this->buttonLine->Size = System::Drawing::Size(50, 50);
				 this->buttonLine->TabIndex = 2;
				 this->buttonLine->UseVisualStyleBackColor = true;
				 this->buttonLine->Click += gcnew System::EventHandler(this, &BresForm::buttonLine_Click);
				 // 
				 // buttonEllipse
				 // 
				 this->buttonEllipse->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonEllipse.BackgroundImage")));
				 this->buttonEllipse->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
				 this->buttonEllipse->Location = System::Drawing::Point(6, 81);
				 this->buttonEllipse->Name = L"buttonEllipse";
				 this->buttonEllipse->Size = System::Drawing::Size(50, 50);
				 this->buttonEllipse->TabIndex = 1;
				 this->buttonEllipse->UseVisualStyleBackColor = true;
				 this->buttonEllipse->Click += gcnew System::EventHandler(this, &BresForm::buttonEllipse_Click);
				 // 
				 // buttonCircle
				 // 
				 this->buttonCircle->BackColor = System::Drawing::SystemColors::Control;
				 this->buttonCircle->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonCircle.BackgroundImage")));
				 this->buttonCircle->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
				 this->buttonCircle->Location = System::Drawing::Point(6, 12);
				 this->buttonCircle->Name = L"buttonCircle";
				 this->buttonCircle->Size = System::Drawing::Size(50, 50);
				 this->buttonCircle->TabIndex = 0;
				 this->buttonCircle->UseVisualStyleBackColor = false;
				 this->buttonCircle->Click += gcnew System::EventHandler(this, &BresForm::buttonCircle_Click);
				 // 
				 // trackBarThick
				 // 
				 this->trackBarThick->Cursor = System::Windows::Forms::Cursors::Default;
				 this->trackBarThick->Location = System::Drawing::Point(194, 34);
				 this->trackBarThick->Name = L"trackBarThick";
				 this->trackBarThick->Size = System::Drawing::Size(194, 45);
				 this->trackBarThick->TabIndex = 24;
				 this->trackBarThick->TickStyle = System::Windows::Forms::TickStyle::None;
				 this->trackBarThick->Scroll += gcnew System::EventHandler(this, &BresForm::trackBar1_Scroll);
				 // 
				 // pictureBox1
				 // 
				 this->pictureBox1->Location = System::Drawing::Point(418, 27);
				 this->pictureBox1->Name = L"pictureBox1";
				 this->pictureBox1->Size = System::Drawing::Size(52, 52);
				 this->pictureBox1->TabIndex = 25;
				 this->pictureBox1->TabStop = false;
				 // 
				 // textBoxDebug
				 // 
				 this->textBoxDebug->Location = System::Drawing::Point(98, 487);
				 this->textBoxDebug->Name = L"textBoxDebug";
				 this->textBoxDebug->Size = System::Drawing::Size(400, 20);
				 this->textBoxDebug->TabIndex = 26;
				 // 
				 // buttonRect
				 // 
				 this->buttonRect->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonRect.BackgroundImage")));
				 this->buttonRect->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
				 this->buttonRect->Location = System::Drawing::Point(6, 207);
				 this->buttonRect->Name = L"buttonRect";
				 this->buttonRect->Size = System::Drawing::Size(50, 50);
				 this->buttonRect->TabIndex = 6;
				 this->buttonRect->UseVisualStyleBackColor = true;
				 this->buttonRect->Click += gcnew System::EventHandler(this, &BresForm::buttonRect_Click);
				 // 
				 // BresForm
				 // 
				 this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
				 this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				 this->ClientSize = System::Drawing::Size(525, 511);
				 this->Controls->Add(this->textBoxDebug);
				 this->Controls->Add(this->pictureBox1);
				 this->Controls->Add(this->trackBarThick);
				 this->Controls->Add(this->panel1);
				 this->Controls->Add(this->pictureBox);
				 this->Controls->Add(this->checkBoxBres);
				 this->Controls->Add(this->menuStrip1);
				 this->Name = L"BresForm";
				 this->Text = L"BresForm";
				 this->Load += gcnew System::EventHandler(this, &BresForm::BresForm_Load);
				 (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox))->EndInit();
				 this->menuStrip1->ResumeLayout(false);
				 this->menuStrip1->PerformLayout();
				 this->panel1->ResumeLayout(false);
				 (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBarThick))->EndInit();
				 (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
				 this->ResumeLayout(false);
				 this->PerformLayout();

			 }
#pragma endregion
	private: System::Void BresForm_Load(System::Object^  sender, System::EventArgs^  e) {
		//_ghostBrush = %SolidBrush(Color::FromArgb(200, 200, 200, 255)); //This creates a slightly blue, transparent brush for the ghost preview
	}

	private: System::Void checkBox1_CheckedChanged(System::Object^  sender, System::EventArgs^  e)
	{
		bresenham = !bresenham;
	}
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		refresh();
	}
	private: System::Void pictureBox_Click(System::Object^  sender, System::EventArgs^  e)
	{
		
	}

	private: System::Void buttonCircle_Click(System::Object^  sender, System::EventArgs^  e)
	{
		tool = 1;
	}
	private: System::Void buttonLine_Click(System::Object^  sender, System::EventArgs^  e)
	{
		tool = 0;
	}

	private: System::Void buttonEllipse_Click(System::Object^  sender, System::EventArgs^  e)
	{
		tool = 2;
	}

	private: System::Void trackBarThick_Scroll(System::Object^  sender, System::EventArgs^  e) {

	}

	private: System::Void menuStrip1_ItemClicked(System::Object^  sender, System::Windows::Forms::ToolStripItemClickedEventArgs^  e) {
	}
	private: System::Void aboutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		String ^text = "����� ����� ������������, ���141\n25.09.17" +
			"\n������ 1. ��������� ����������" +
			"\nVisual Studio 2017 Community, Windows 10" +
			"\n���������� ������" +
			"\n���������� ���������� � �������(������ - ���������� ������)";
		MessageBox::Show(text, "� ���������", MessageBoxButtons::OK,
			MessageBoxIcon::Asterisk);
	}


	private: System::Void trackBar1_Scroll(System::Object^  sender, System::EventArgs^  e) {
		thickness = trackBarThick->Value;
	}



	private: System::Void pictureBox_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) 
	{
		Point p = pictureBox->PointToClient(Cursor->Position);

		if (e->Button == System::Windows::Forms::MouseButtons::Left)
		{
			currentPoint = Point(e->X, e->Y);
		}
		
	}

	private: System::Void pictureBox_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) 
	{
		if (e->Button == System::Windows::Forms::MouseButtons::Left)
		{
			draw = true;
			mRect = System::Drawing::Rectangle(currentPoint.X, currentPoint.Y, e->X - currentPoint.X, e->Y - currentPoint.Y);
			pictureBox->Invalidate();
		}
	}
	private: System::Void pictureBox_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) 
	{		
		if (fill)
		{
			Bitmap ^tmp = gcnew Bitmap(pictureBox->Width, pictureBox->Height);// bm);

			Graphics ^g = Graphics::FromImage(tmp);
			SeedFill(g, currentPoint,Color::Magenta);
			e->Graphics->DrawImage(tmp, 0, 0);
			fill = false;
		}
		if (draw)
		{
			Bitmap ^tmp = gcnew Bitmap(pictureBox->Width, pictureBox->Height);// bm);

			Graphics ^g = Graphics::FromImage(tmp);
			paint(e->Graphics,false);

			//drawEllipse(g, currentPoint, mRect.Width, mRect.Height);
			e->Graphics->DrawImage(tmp, 0, 0);
		}
		if (!fill && !draw)
		{
			e->Graphics->DrawImage(bm, 0, 0);
		}

		

	}
	private: System::Void pictureBox_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e)
	{
		if (e->Button == System::Windows::Forms::MouseButtons::Left&&!fill)
		{
			//Create a Graphics for the offscreen bitmap
			Graphics ^g = Graphics::FromImage(bm);
			System::Drawing::Rectangle rect = System::Drawing::Rectangle(currentPoint.X, currentPoint.Y, e->X - currentPoint.X, e->Y - currentPoint.Y);
			
			paint(g,true);
			if (tool == 3)			{
				
				CohenSutherlandClipping(mRect, g,0);
			}
			
			line_start = Point(-1, -1);
		}

		draw = false;

		//This queues up a redraw call for the form
		pictureBox->Invalidate();

	}
private: System::Void buttonFill_Click(System::Object^  sender, System::EventArgs^  e) {
	fill = !fill;
	draw = false;
}

private: System::Void buttonRect_Click(System::Object^  sender, System::EventArgs^  e) {
	tool = 3;
}
};
}
